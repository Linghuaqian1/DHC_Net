# #!/user/bin/env python3
# # -*- coding: utf-8 -*-
#
# import seaborn as sns
# import matplotlib.pyplot as plt
# import numpy as np
#
# # 假设这是你的三元组数据
# triplets = [
#     (0, 0, 0.9), (0, 1, 0.1), (1, 0, 0.2), (1, 1, 0.8),
#     (2, 2, 0.7), (2, 3, 0.3), (3, 2, 0.6), (3, 3, 0.4)
#     # 这里添加更多的三元组
# ]
#
# # 根据三元组创建一个空矩阵
# num_classes = 19  # 根据你的数据集设置类别数量
# matrix = np.zeros((num_classes, num_classes))
#
# # 将三元组中的值填入矩阵
# for x, y, value in triplets:
#     matrix[x, y] = value
#
# # 类别标签，根据你的数据集进行调整
# labels = ["plane", "ship", "storage-tank", "baseball-diamond", "tennis-court", "basketball-court",
#           "ground-track-field", "harbor", "bridge", "large-vehicle", "small-vehicle", "helicopter",
#           "roundabout", "soccer-ball-field", "swimming-pool", "container-crane", "airport", "helipad", "background"]
#
# # 确保标签长度与类别数量一致
# labels = labels[:num_classes]
#
# plt.figure(figsize=(12, 10))
# sns.heatmap(matrix, annot=True, fmt='.2f', cmap='Blues', xticklabels=labels, yticklabels=labels)
# plt.title('Confusion Matrix Normalized')
# plt.xlabel('True')
# plt.ylabel('Predicted')
# plt.show()
#
# !/user/bin/env python3
# -*- coding: utf-8 -*-

import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# 假设这是你的三元组数据
triplets = [
    (0, 0, 0.90), (0, 11, 0.23), (0, 18, 0.02), (1, 1, 0.83), (1, 7, 0.01), (1, 18, 0.09), (2, 2, 0.73), (2, 8, 0.01),
    (3, 3, 0.79), (4, 4, 0.93), (4, 5, 0.02), (5, 5, 0.68), (5, 13, 0.03), (6, 6, 0.64), (6, 13, 0.02), (7, 7, 0.81),
    (7, 18, 0.06), (8, 8, 0.54), (8, 18, 0.01), (9, 9, 0.77), (9, 10, 0.01), (9, 18, 0.09), (10, 9, 0.07),
    (10, 10, 0.61), (10, 18, 0.63), (11, 11, 0.55), (11, 18, 0.01), (12, 12, 0.60), (13, 5, 0.01),
    (13, 6, 0.02), (13, 13, 0.48), (13, 18, 0.01), (14, 14, 0.69), (14, 18, 0.01), (16, 16, 0.87),
    (18, 0, 0.09), (18, 1, 0.17), (18, 2, 0.27), (18, 3, 0.21), (18, 4, 0.06), (18, 5, 0.28),
    (18, 6, 0.34), (18, 7, 0.18), (18, 8, 0.45), (18, 9, 0.16), (18, 10, 0.38), (18, 11, 0.22), (18, 12, 0.40),
    (18, 13, 0.47), (18, 14, 0.31),    (18, 15, 1.00), (18, 16, 0.13), (18, 17, 1.00)
    # 这里添加更多的三元组
]

# 根据三元组创建一个空矩阵
num_classes = 19  # 根据你的数据集设置类别数量
matrix = np.zeros((num_classes, num_classes))

# 将三元组中的值填入矩阵
for x, y, value in triplets:
    matrix[x, y] = value
matrix[matrix == 0] = np.nan
# 类别标签，根据你的数据集进行调整
labels = ["PL", "SH", "ST", "BD", "TC", "BC",
          "GTF", "HB", "BR", "LV", "SV", "HC",
          "RA", "SBF", "SP", "CC", "AP", "HP", "BG"]

# 确保标签长度与类别数量一致
labels = labels[:num_classes]

plt.figure(figsize=(12, 10))
sns.heatmap(matrix, annot=True, fmt='.2f', cmap='Blues', xticklabels=labels, yticklabels=labels,
            annot_kws={"size": 9})
plt.xticks(rotation=90, fontsize=13)
plt.yticks(rotation=0, fontsize=13)
plt.title('Confusion Matrix Normalized', fontsize=16)
plt.xlabel('True', fontsize=15)
plt.ylabel('Predicted', fontsize=15)
plt.show()
